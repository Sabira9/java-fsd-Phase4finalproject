import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Data } from '../data';

import { EmployeeserviceService } from '../employeeservice.service';
@Component({
  selector: 'app-addemp',
  templateUrl: './addemp.component.html',
  styleUrls: ['./addemp.component.css'],
})
export class AddempComponent implements OnInit {
  newemp: Data = {
    id: 0,
    first_name: '',
    last_name: '',
    email: '',
  };
  postData() {
    this.rservice.addemp(this.newemp).subscribe({
      next: (res: any) => {
        this.router.navigate(['/add']);
      },
      error: (err: any) => {
        console.log(err);
      },
    });
  }

  constructor(
    private rservice: EmployeeserviceService,
    private router: Router
  ) {}
  ngOnInit(): void {}
}
