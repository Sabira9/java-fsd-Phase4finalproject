import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Data } from './data';

@Injectable({
  providedIn: 'root',
})
export class EmployeeserviceService {
  constructor(private http: HttpClient) {}
  //get data from database
  getData() {
    return this.http.get<Data[]>('http://localhost:3000/employees');
  }
  //Add Data
  addemp(data: Data)
  { 
  return this.http.post<Data>('http://localhost:3000/employees',data)
  }
  //get single data by id
  getdatabyId(id: number)
  { 
    return this.http.get<Data>(`http://localhost:3000/employees/${id}`);
  }
  //Update data 
  updateData(data: Data)
  { 
    return this.http.put<Data>(`http://localhost:3000/employees/${data.id}`,data)
  }
  //delete 
  deletebyid(id: number)
  {
    return this.http.delete<Data>(`http://localhost:3000/employees/${id}`);
  }
}
