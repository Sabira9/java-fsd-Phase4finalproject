import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Data } from '../data';
import { EmployeeserviceService } from '../employeeservice.service';

@Component({
  selector: 'app-crudoperation',
  templateUrl: './crudoperation.component.html',
  styleUrls: ['./crudoperation.component.css'],
})
export class CrudoperationComponent implements OnInit {
  allData: Data[] = [];
  response: any;
  constructor(
    private es: EmployeeserviceService,
    private router: Router,
    private activer: ActivatedRoute
  ) {
    this.get();
  }

  ngOnInit(): void {}
  get() {
    this.es.getData().subscribe((res) => {
      this.allData = res;
      console.log(this.allData);
    });
  }
  delete(id: number) {
    this.es.deletebyid(id).subscribe({
      next: (res: any) => {
        this.get();
        alert('Deleted Employee!!!');
      },
      error: (err: any) => {
        console.log(err);
      }
    });
   
  }
}
