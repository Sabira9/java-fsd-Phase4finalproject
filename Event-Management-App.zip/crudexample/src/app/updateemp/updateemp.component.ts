import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Data } from '../data';
import { EmployeeserviceService } from '../employeeservice.service';

@Component({
  selector: 'app-updateemp',
  templateUrl: './updateemp.component.html',
  styleUrls: ['./updateemp.component.css'],
})
export class UpdateempComponent implements OnInit {
  constructor(
    private rservice: EmployeeserviceService,
    private router: Router,
    private activer: ActivatedRoute
  ) {}
  newemp: Data = {
    id: 0,
    first_name: '',
    last_name: '',
    email: '',
  };
  ngOnInit(): void {
    this.activer.paramMap.subscribe((param) => {
      var id = Number(param.get('id'));
      this.getdatabyId(id);
    });
  }
  getdatabyId(id: number) {
    this.rservice.getdatabyId(id).subscribe((data) => {
      this.newemp = data;
    });
  }

  update() {
    this.rservice.updateData(this.newemp).subscribe({
      next: (res: any) => {
        this.router.navigate(['/add']);
      },
      error: (err: any) => {
        console.log(err);
      },
    });
  }
}
