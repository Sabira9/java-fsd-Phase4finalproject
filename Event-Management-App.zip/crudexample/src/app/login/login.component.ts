import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  constructor(private router: Router) {}
  msg:string=""
  ngOnInit(): void {}
  checklogin(loginRef:any) {
    console.log('submitted',loginRef);
    console.log(loginRef.value?.['email']);
    if(loginRef.value?.["email"]== "admin@gmail.com" && loginRef.value?.["pwd"] == "1234"){
     this.router.navigate(['/add'])
    }else{
      alert("Failure Try Again!");
    }
  }
  }
  
